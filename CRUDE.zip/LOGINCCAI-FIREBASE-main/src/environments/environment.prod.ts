export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyCcyAusuuQYdOGAn_4uTtTAOx3oRuG9Yi4",
    authDomain: "empleados-8007c.firebaseapp.com",
    projectId: "empleados-8007c",
    storageBucket: "empleados-8007c.appspot.com",
    messagingSenderId: "74198623718",
    appId: "1:74198623718:web:98a3603196e3882e3f6227"
  }
};
