// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase:{
    apiKey: "AIzaSyCcyAusuuQYdOGAn_4uTtTAOx3oRuG9Yi4",
    authDomain: "empleados-8007c.firebaseapp.com",
    projectId: "empleados-8007c",
    storageBucket: "empleados-8007c.appspot.com",
    messagingSenderId: "74198623718",
    appId: "1:74198623718:web:98a3603196e3882e3f6227"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
